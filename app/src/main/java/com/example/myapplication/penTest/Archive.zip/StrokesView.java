package com.example.myapplication.penTest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;


public class StrokesView extends View {
    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private  DrawingStrokes mDrawing;
    public StrokesView(Context context, AttributeSet attributeSet){
        super(context,attributeSet);
        //笔划
        Strokes strokes = new Strokes();
        mDrawing = new DrawingStrokes(this, strokes);
        mDrawing.setMaxWidth(100);
    }
    @Override
    protected void onDraw(Canvas canvas) {
        if(mDrawing != null) {
            mDrawing.setSize(canvas.getWidth(),canvas.getHeight(),mPaint);
            mDrawing.draw(canvas, mPaint);
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN) {
            mDrawing.moveTo(event.getX(), event.getY(), event.getPressure());
        } else if(action == MotionEvent.ACTION_MOVE){
            int historySize = event.getHistorySize();
            for (int i = 0; i < historySize; i++) {
                float historicalX = event.getHistoricalX(i);
                float historicalY = event.getHistoricalY(i);
                //判断两点之间的距离是否太短
                double distance = Math.sqrt((historicalX - mDrawing.pointList.get(mDrawing.pointList.size() - 1).getX())
                        * (historicalX - mDrawing.pointList.get(mDrawing.pointList.size() - 1).getX())
                        + (historicalY - mDrawing.pointList.get(mDrawing.pointList.size() - 1).getY())
                        * (historicalY - mDrawing.pointList.get(mDrawing.pointList.size() - 1).getY()));
                if(mDrawing.pointList.size() > 0 && distance > 0.2)
                    mDrawing.lineTo(historicalX, historicalY, event.getHistoricalPressure(i),false);
            }
        }else if(action == MotionEvent.ACTION_UP) {
            mDrawing.lineTo(event.getX(), event.getY(), event.getPressure(),true);
        }
        invalidate();
        return true;
    }

}

