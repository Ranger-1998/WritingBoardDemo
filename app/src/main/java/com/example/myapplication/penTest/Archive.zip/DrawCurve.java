package com.example.myapplication.penTest;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

public class DrawCurve {
    private int curveIndex = 2;
    private float startWidth;
    private float endWidth;
    private Curve curve;
    protected Canvas canvas;
    protected Paint curvePaint;
    private TimePoint lastTop, lastBottom;
    private Path curvePath;

    public DrawCurve(Curve curve, float startWidth, float endWidth, Canvas canvas, Paint curvePaint) {
        this.curve = curve;
        this.startWidth = startWidth;
        this.endWidth = endWidth;
        this.canvas = canvas;
        this.curvePaint = curvePaint;
        this.curvePath = new Path();
    }

    public void updateData(float startWidth, float endWidth, Curve curve) {
        this.curve = curve;
        this.startWidth = startWidth;
        this.endWidth = endWidth;
    }

    public void initLastPoint(TimePoint lastTop, TimePoint lastBottom) {
        this.lastTop = lastTop;
        this.lastBottom = lastBottom;
    }

    public void draw(DrawingStrokes drawingStrokes) {
        //测试笔锋填充的效果
        curvePaint.setStyle(Paint.Style.FILL);
        curvePaint.setColor(Color.BLACK);

        //获得笔在两点间不同宽度的差值
        int drawSteps = (int) Math.floor(curve.length());
        if (drawingStrokes.isUp) {
            if (drawSteps > 2)
                curveIndex = (drawSteps - 2) / 2;
            else curveIndex = 1;
            if (curveIndex < 1) curveIndex = 1;
            if (drawSteps == 0) drawSteps = 2;
        } else if (drawingStrokes.isDown) {
            curveIndex = 1;
            if (drawSteps == 0) drawSteps = 2;
        } else {
            if (drawSteps > 100) curveIndex = 40;
            else if (drawSteps > 80) curveIndex = 35;
            else if (drawSteps > 70) curveIndex = 30;
            else if (drawSteps > 60) curveIndex = 25;
            else if (drawSteps > 50) curveIndex = 20;
            else if (drawSteps > 40) curveIndex = 15;
            else if (drawSteps > 30) curveIndex = 13;
            else if (drawSteps > 20) curveIndex = 9;
            else if (drawSteps > 10) curveIndex = 7;
            else if (drawSteps >= 4) curveIndex = 3;
            else curveIndex = 1;
        }
        float widthDelta = endWidth - startWidth;
        //两点间实际轨迹距离
        float k = 0;
        TimePoint myPointC, myPointD, myPointA, myPointB;

        if (drawSteps == 0) {
            drawSteps = 1;
        }

        for (int i = 0, num = 1; i < drawSteps; i += curveIndex, num++) {
            curvePath.reset();
            float t = (float) (i) / drawSteps;
            float tt = t * t;
            float ttt = tt * t;
            float u = 1 - t;
            float uu = u * u;
            float uuu = uu * u;

            float t1 = -3 * ttt + 3 * tt + 3 * t + 1;
            float t2 = 3 * ttt - 6 * tt + 4;

            float x = uuu * curve.point1.x / 6.0f;
            x += t2 * curve.point2.x / 6.0f;
            x += t1 * curve.point3.x / 6.0f;
            x += ttt * curve.point4.x / 6.0f;
            float y = uuu * curve.point1.y / 6.0f;
            y += t2 * curve.point2.y / 6.0f;
            y += t1 * curve.point3.y / 6.0f;
            y += ttt * curve.point4.y / 6.0f;
            float currentWidth = startWidth + t * widthDelta;
            if (!drawingStrokes.isUp)
                if (Math.abs(t * widthDelta) > 0.2f * num) {
                    if (t * widthDelta > 0)
                        currentWidth = startWidth + 0.2f * num;
                    else currentWidth = startWidth - 0.2f * num;
                }
            DrawingStrokes.DrawingState currentState = DrawingStrokes.DrawingState.NO_STATE;
            float numX = x - drawingStrokes.mLastX;
            float numY = y - drawingStrokes.mLastY;
            if (numX > 0 && numY < 0) currentState = DrawingStrokes.DrawingState.X_ADD_Y_DEC;
            if (numX > 0 && numY == 0) currentState = DrawingStrokes.DrawingState.X_ADD_Y_SAM;
            if (numX < 0 && numY > 0) currentState = DrawingStrokes.DrawingState.X_DEC_Y_ADD;
            if (numX < 0 && numY < 0) currentState = DrawingStrokes.DrawingState.X_DEC_Y_DEC;
            if (numX < 0 && numY == 0) currentState = DrawingStrokes.DrawingState.X_DEC_Y_SAM;
            if (numX == 0 && numY > 0) currentState = DrawingStrokes.DrawingState.X_SAM_Y_ADD;
            if (numX == 0 && numY < 0) currentState = DrawingStrokes.DrawingState.X_SAM_Y_DEC;
            if (numX == 0 && numY == 0) currentState = DrawingStrokes.DrawingState.X_SAM_Y_SAM;
            if (x != drawingStrokes.mLastX) {
                k = (y - drawingStrokes.mLastY) / (x - drawingStrokes.mLastX);
                //上个点的上下端点MyPointA,MyPointB
                myPointA = new TimePoint((drawingStrokes.mLastWidth / 2) * (-k) / (float) Math.sqrt(k * k + 1) + drawingStrokes.mLastX,
                        (drawingStrokes.mLastWidth / 2) / (float) Math.sqrt(k * k + 1) + drawingStrokes.mLastY);
                myPointB = new TimePoint((-drawingStrokes.mLastWidth / 2) * (-k) / (float) Math.sqrt(k * k + 1) + drawingStrokes.mLastX,
                        (-drawingStrokes.mLastWidth / 2) / (float) Math.sqrt(k * k + 1) + drawingStrokes.mLastY);
                //当前点的上下端点MyPointC,MyPointD
                myPointC = new TimePoint((currentWidth / 2) * (-k) / (float) Math.sqrt(k * k + 1) + x,
                        (currentWidth / 2) / (float) Math.sqrt(k * k + 1) + y);
                myPointD = new TimePoint((-currentWidth / 2) * (-k) / (float) Math.sqrt(k * k + 1) + x,
                        (-currentWidth / 2) / (float) Math.sqrt(k * k + 1) + y);

            } else {
                myPointA = new TimePoint(drawingStrokes.mLastWidth / 2 + drawingStrokes.mLastX,
                        drawingStrokes.mLastY);
                myPointB = new TimePoint(-drawingStrokes.mLastWidth / 2 + drawingStrokes.mLastX,
                        drawingStrokes.mLastY);
                myPointC = new TimePoint(currentWidth / 2 + x,
                        y);
                myPointD = new TimePoint(-currentWidth / 2 + x,
                        y);
            }
            if (drawingStrokes.isDown) {//起点  需要算AB
                //算出矩形的四个点
                TimePoint A, B, C, D;
                if (myPointA.x != myPointB.x) {
                    k = (myPointA.y - myPointB.y) / (myPointA.x - myPointB.x);
                    A = new TimePoint((drawingStrokes.mLastWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointA.x,
                            (drawingStrokes.mLastWidth) / (float) Math.sqrt(k * k + 1) + myPointA.y);
                    B = new TimePoint((-drawingStrokes.mLastWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointA.x,
                            (-drawingStrokes.mLastWidth) / (float) Math.sqrt(k * k + 1) + myPointA.y);
                    //当前点的上下端点MyPointC,MyPointD
                    C = new TimePoint((drawingStrokes.mLastWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointB.x,
                            (drawingStrokes.mLastWidth) / (float) Math.sqrt(k * k + 1) + myPointB.y);
                    D = new TimePoint((-drawingStrokes.mLastWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointB.x,
                            (-drawingStrokes.mLastWidth) / (float) Math.sqrt(k * k + 1) + myPointB.y);

                } else {
                    A = new TimePoint(drawingStrokes.mLastWidth + myPointA.x,
                            myPointA.y);
                    B = new TimePoint(-drawingStrokes.mLastWidth + myPointA.x,
                            myPointA.y);
                    C = new TimePoint(drawingStrokes.mLastWidth + myPointB.x,
                            myPointB.y);
                    D = new TimePoint(-drawingStrokes.mLastWidth / 2 + myPointB.x,
                            myPointB.y);
                }
                TimePoint centerAC = new TimePoint((A.x + C.x) / 2, (A.y + C.y) / 2);
                TimePoint centerBD = new TimePoint((B.x + D.x) / 2, (B.y + D.y) / 2);
                boolean isAC;
                if (myPointA.x != myPointB.x) {
                    float b = myPointA.y - k * myPointA.x;
                    isAC = (centerAC.y - k * centerAC.x - b) * (drawingStrokes.pointList.get(3).y - k * drawingStrokes.pointList.get(3).x - b) <= 0;

                } else {
                    isAC = (centerAC.y - myPointA.y) * (drawingStrokes.pointList.get(3).y - myPointA.y) <= 0;
                }


                curvePath.moveTo(myPointB.x, myPointB.y);
                if (isAC)
                    curvePath.quadTo(centerAC.x, centerAC.y, myPointA.x, myPointA.y);
                else curvePath.quadTo(centerBD.x, centerBD.y, myPointA.x, myPointA.y);
                curvePath.lineTo(myPointC.x, myPointC.y);
                curvePath.lineTo(myPointD.x, myPointD.y);
                curvePath.lineTo(myPointB.x, myPointB.y);
                canvas.drawPath(curvePath, curvePaint);
                curvePath.reset();


                drawingStrokes.isDown = false;

                drawingStrokes.strokesPath.moveTo(myPointB.x, myPointB.y);
                if (isAC) {
                    drawingStrokes.strokesPath.quadTo(centerAC.x, centerAC.y, myPointA.x, myPointA.y);
                    drawingStrokes.strokes.getStrokes().get(drawingStrokes
                            .strokes.getStrokes().size() - 1).addPoint(new TimePoint(centerAC.x, centerAC.y));
                } else {
                    drawingStrokes.strokesPath.quadTo(centerBD.x, centerBD.y, myPointA.x, myPointA.y);
                    drawingStrokes.strokes.getStrokes().get(drawingStrokes
                            .strokes.getStrokes().size() - 1).addPoint(new TimePoint(centerBD.x, centerBD.y));
                }

                drawingStrokes.strokesPath.lineTo(myPointC.x, myPointC.y);
                drawingStrokes.lastLineX = myPointC.x;
                drawingStrokes.lastLineY = myPointC.y;
                drawingStrokes.timePoints.add(new TimePoint(myPointB.x, myPointB.y));
                drawingStrokes.timePoints.add(new TimePoint(myPointD.x, myPointD.y));

            } else {
                //相交为180
                if (!((drawingStrokes.mLLastX == drawingStrokes.mLastX && drawingStrokes.mLastX == x)
                        || (drawingStrokes.mLLastX != drawingStrokes.mLastX && drawingStrokes.mLastX
                        != x && (k == drawingStrokes.mLastK || -k == drawingStrokes.mLastK)))) {
                    //判断外端点画弧
                    float degreeA = drawingStrokes.calculateDegree(drawingStrokes.mLastX, drawingStrokes.mLastY,
                            drawingStrokes.mLLastX, drawingStrokes.mLLastY, myPointA.x, myPointA.y);
                    float degreeB = drawingStrokes.calculateDegree(drawingStrokes.mLastX, drawingStrokes.mLastY,
                            drawingStrokes.mLLastX, drawingStrokes.mLLastY, myPointB.x, myPointB.y);
                    float degreeLT = drawingStrokes.calculateDegree(drawingStrokes.mLastX, drawingStrokes.mLastY,
                            x, y, lastTop.x, lastTop.y);
                    float degreeLB = drawingStrokes.calculateDegree(drawingStrokes.mLastX, drawingStrokes.mLastY,
                            x, y, lastBottom.x, lastBottom.y);
                    //谁大谁是外端点
                    if ((degreeA >= degreeB && degreeLT >= degreeLB) || (degreeA <= degreeB && degreeLT <= degreeLB)) {

                        //填充
                        curvePath.moveTo(myPointA.x, myPointA.y);
                        curvePath.lineTo(lastTop.x, lastTop.y);
                        curvePath.lineTo(lastBottom.x, lastBottom.y);
                        curvePath.lineTo(myPointB.x, myPointB.y);
                        curvePath.lineTo(myPointA.x, myPointA.y);
                        canvas.drawPath(curvePath, curvePaint);
                        curvePath.reset();

                        if (drawingStrokes.lastLineX == lastTop.x && drawingStrokes.lastLineY == lastTop.y) {
                            drawingStrokes.strokesPath.lineTo(myPointA.x, myPointA.y);
                            drawingStrokes.timePoints.add(new TimePoint(myPointB.x, myPointB.y));
                            drawingStrokes.lastLineX = myPointA.x;
                            drawingStrokes.lastLineY = myPointA.y;
                        } else {
                            drawingStrokes.strokesPath.lineTo(myPointB.x, myPointB.y);
                            drawingStrokes.timePoints.add(new TimePoint(myPointA.x, myPointA.y));
                            drawingStrokes.lastLineX = myPointB.x;
                            drawingStrokes.lastLineY = myPointB.y;
                        }
                    } else {
                        //测试
                        if (drawingStrokes.intersect(myPointA.x, myPointA.y, lastBottom.x, lastBottom.y, x, y, drawingStrokes.mLastX, drawingStrokes.mLastY)
                                || drawingStrokes.intersect(myPointA.x, myPointA.y, lastBottom.x, lastBottom.y, drawingStrokes.mLLastX, drawingStrokes.mLLastY,
                                drawingStrokes.mLastX, drawingStrokes.mLastY)) {
                            //转弯了
                            if (drawingStrokes.state != DrawingStrokes.DrawingState.NO_STATE
                                    && drawingStrokes.state != currentState) {

                                curvePath.moveTo(myPointA.x, myPointA.y);
                                curvePath.lineTo(lastBottom.x, lastBottom.y);
                                curvePath.lineTo(lastTop.x, lastTop.y);
                                curvePath.lineTo(myPointB.x, myPointB.y);
                                curvePath.lineTo(myPointA.x, myPointA.y);
                                canvas.drawPath(curvePath, curvePaint);
                                curvePath.reset();

                                if (drawingStrokes.lastLineX == lastBottom.x && drawingStrokes.lastLineY == lastBottom.y) {
                                    drawingStrokes.strokesPath.lineTo(myPointA.x, myPointA.y);
                                    drawingStrokes.timePoints.add(new TimePoint(myPointB.x, myPointB.y));
                                    drawingStrokes.lastLineX = myPointA.x;
                                    drawingStrokes.lastLineY = myPointA.y;
                                } else {
                                    drawingStrokes.strokesPath.lineTo(myPointB.x, myPointB.y);
                                    drawingStrokes.timePoints.add(new TimePoint(myPointA.x, myPointA.y));
                                    drawingStrokes.lastLineX = myPointB.x;
                                    drawingStrokes.lastLineY = myPointB.y;
                                }
                            } else {

                                curvePath.moveTo(myPointA.x, myPointA.y);
                                curvePath.lineTo(lastTop.x, lastTop.y);
                                curvePath.lineTo(lastBottom.x, lastBottom.y);
                                curvePath.lineTo(myPointB.x, myPointB.y);
                                curvePath.lineTo(myPointA.x, myPointA.y);
                                canvas.drawPath(curvePath, curvePaint);
                                curvePath.reset();

                                if (drawingStrokes.lastLineX == lastTop.x && drawingStrokes.lastLineY == lastTop.y) {
                                    drawingStrokes.strokesPath.lineTo(myPointA.x, myPointA.y);
                                    drawingStrokes.timePoints.add(new TimePoint(myPointB.x, myPointB.y));
                                    drawingStrokes.lastLineX = myPointA.x;
                                    drawingStrokes.lastLineY = myPointA.y;
                                } else {
                                    drawingStrokes.strokesPath.lineTo(myPointB.x, myPointB.y);
                                    drawingStrokes.timePoints.add(new TimePoint(myPointA.x, myPointA.y));
                                    drawingStrokes.lastLineX = myPointB.x;
                                    drawingStrokes.lastLineY = myPointB.y;
                                }
                            }
                        } else {

                            //填充
                            curvePath.moveTo(myPointA.x, myPointA.y);
                            curvePath.lineTo(lastBottom.x, lastBottom.y);
                            curvePath.lineTo(lastTop.x, lastTop.y);
                            curvePath.lineTo(myPointB.x, myPointB.y);
                            curvePath.lineTo(myPointA.x, myPointA.y);
                            canvas.drawPath(curvePath, curvePaint);
                            curvePath.reset();

                            if (drawingStrokes.lastLineX == lastBottom.x && drawingStrokes.lastLineY == lastBottom.y) {
                                drawingStrokes.strokesPath.lineTo(myPointA.x, myPointA.y);
                                drawingStrokes.timePoints.add(new TimePoint(myPointB.x, myPointB.y));
                                drawingStrokes.lastLineX = myPointA.x;
                                drawingStrokes.lastLineY = myPointA.y;
                            } else {
                                drawingStrokes.strokesPath.lineTo(myPointB.x, myPointB.y);
                                drawingStrokes.timePoints.add(new TimePoint(myPointA.x, myPointA.y));
                                drawingStrokes.lastLineX = myPointB.x;
                                drawingStrokes.lastLineY = myPointB.y;
                            }
                        }
                    }
                }

                //填充
                curvePath.moveTo(myPointA.x, myPointA.y);
                curvePath.lineTo(myPointC.x, myPointC.y);
                curvePath.lineTo(myPointD.x, myPointD.y);
                curvePath.lineTo(myPointB.x, myPointB.y);
                curvePath.lineTo(myPointA.x, myPointA.y);
                canvas.drawPath(curvePath, curvePaint);
                curvePath.reset();

                if (drawingStrokes.lastLineX == myPointA.x && drawingStrokes.lastLineY == myPointA.y) {
                    drawingStrokes.strokesPath.lineTo(myPointC.x, myPointC.y);

                    drawingStrokes.timePoints.add(new TimePoint(myPointD.x, myPointD.y));
                    drawingStrokes.lastLineX = myPointC.x;
                    drawingStrokes.lastLineY = myPointC.y;
                } else {
                    drawingStrokes.strokesPath.lineTo(myPointD.x, myPointD.y);

                    drawingStrokes.timePoints.add(new TimePoint(myPointC.x, myPointC.y));
                    drawingStrokes.lastLineX = myPointD.x;
                    drawingStrokes.lastLineY = myPointD.y;
                }
            }
            if (drawingStrokes.isUp && i >= drawSteps - curveIndex) {

                drawingStrokes.isUp = false;
                TimePoint A, B, C, D;
                if (myPointC.x != myPointD.x) {
                    k = (myPointC.y - myPointD.y) / (myPointC.x - myPointD.x);
                    A = new TimePoint((currentWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointC.x,
                            (currentWidth) / (float) Math.sqrt(k * k + 1) + myPointC.y);
                    B = new TimePoint((-currentWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointD.x,
                            (-currentWidth) / (float) Math.sqrt(k * k + 1) + myPointD.y);
                    //当前点的上下端点MyPointC,MyPointD
                    C = new TimePoint((currentWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointC.x,
                            (currentWidth) / (float) Math.sqrt(k * k + 1) + myPointC.y);
                    D = new TimePoint((-currentWidth) * (-k) / (float) Math.sqrt(k * k + 1) + myPointD.x,
                            (-currentWidth) / (float) Math.sqrt(k * k + 1) + myPointD.y);

                } else {
                    A = new TimePoint(currentWidth + myPointC.x,
                            myPointC.y);
                    B = new TimePoint(-currentWidth + myPointD.x,
                            myPointD.y);
                    C = new TimePoint(currentWidth + myPointC.x,
                            myPointC.y);
                    D = new TimePoint(-currentWidth + myPointD.x,
                            myPointD.y);
                }
                TimePoint centerAC = new TimePoint((A.x + C.x) / 2, (A.y + C.y) / 2);
                TimePoint centerBD = new TimePoint((B.x + D.x) / 2, (B.y + D.y) / 2);
                boolean isAC;
                if (myPointC.x != myPointD.x) {
                    float b = myPointC.y - k * myPointC.x;
                    isAC = (centerAC.y - k * centerAC.x - b) * (drawingStrokes.mLastY - k * drawingStrokes.mLastX - b) <= 0;
                } else {
                    isAC = (centerAC.y - myPointC.y) * (drawingStrokes.mLastY - myPointC.y) <= 0;
                }
                curvePath.moveTo(myPointC.x, myPointC.y);
                if (isAC) {
                    curvePath.quadTo(centerAC.x, centerAC.y, myPointD.x, myPointD.y);
                    if (drawingStrokes.lastLineX == myPointC.x && drawingStrokes.lastLineY == myPointC.y) {
                        drawingStrokes.strokesPath.quadTo(centerAC.x, centerAC.y, myPointD.x, myPointD.y);
                    } else {
                        drawingStrokes.strokesPath.quadTo(centerAC.x, centerAC.y, myPointC.x, myPointC.y);
                    }
                } else {
                    curvePath.quadTo(centerBD.x, centerBD.y, myPointD.x, myPointD.y);
                    if (drawingStrokes.lastLineX == myPointC.x && drawingStrokes.lastLineY == myPointC.y) {
                        drawingStrokes.strokesPath.quadTo(centerBD.x, centerBD.y, myPointD.x, myPointD.y);
                    } else {
                        drawingStrokes.strokesPath.quadTo(centerBD.x, centerBD.y, myPointC.x, myPointC.y);
                    }
                }
                curvePath.lineTo(myPointC.x, myPointC.y);
                canvas.drawPath(curvePath, curvePaint);
                curvePath.reset();
            }
            lastTop.x = myPointC.x;
            lastTop.y = myPointC.y;
            lastBottom.x = myPointD.x;
            lastBottom.y = myPointD.y;
            drawingStrokes.mLastWidth = currentWidth;
            drawingStrokes.mLLastX = drawingStrokes.mLastX;
            drawingStrokes.mLLastY = drawingStrokes.mLastY;
            drawingStrokes.mLastX = x;
            drawingStrokes.mLastY = y;
            drawingStrokes.mLastK = k;
            drawingStrokes.state = currentState;
        }
    }

}
