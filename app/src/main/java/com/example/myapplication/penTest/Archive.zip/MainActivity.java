package com.example.myapplication.penTest;

/**
 * Author:Double
 * Time:2019/4/22
 * Description:This is MainActivity
 */
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    StrokesView strokesView;
    private Button reDo;
    private Button unDo;
    private Button recover;
    private RadioGroup pen_type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pen_test);
        strokesView = (StrokesView)findViewById(R.id.view);
        recover = (Button)findViewById(R.id.recover);
        unDo = (Button)findViewById(R.id.undo);
        reDo = (Button)findViewById(R.id.redo);
        pen_type = (RadioGroup)findViewById(R.id.pen_type);
        recover.setOnClickListener(this);
        unDo.setOnClickListener(this);
        reDo.setOnClickListener(this);
        pen_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

            }
        });

    }
    @Override
    public void onClick(View view) {

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
