package com.example.myapplication.penTest;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Vector;

public class Strokes {
    //当前笔迹列表
    private Vector<Stroke> strokes  = new Vector<>();;

    public Vector<Stroke> getStrokes() {
        return strokes;
    }

    public void draw(Canvas canvas, Paint paint){
        paint.setStyle(Paint.Style.FILL);
        for(int i = 0; i < strokes.size(); i++){
            Path stroke = strokes.elementAt(i).getStroke();
            if(!stroke.isEmpty()){
                canvas.drawPath(stroke,paint);
            }
        }
    }

    public static class Stroke{
        private Path stroke;
        private Vector<TimePoint> points; //拟合后的几个点
        private Vector<TimePoint> originPoints;//最原始的几个点
        private Vector<Float> originWidth;

        Stroke(){
            this.stroke = new Path();
            this.points = new Vector<>();
            originWidth = new Vector<>();
            originPoints = new Vector<>();
        }
        public Path getStroke(){
            return  stroke;
        }
        public void setStroke(Path path){
            stroke = new Path(path);
        }
        public Vector<TimePoint> getOriginPoints(){
            return originPoints;
        }
        public void setOriginPoints(Vector<TimePoint> timePoints){
            this.originPoints = timePoints;
        }
        public void setOriginWidth(Vector<Float> originWidth){
            this.originWidth = originWidth;
        }
        public void addOriginPoint(TimePoint myPoints){
            originPoints.add(myPoints);
        }
        public Vector<Float> getOriginWidth(){
            return originWidth;
        }
        public void addOriginWidth(float width){
            originWidth.add(width);
        }
        public void addPoint(TimePoint point){
            points.add(point);
        }
        public Vector<TimePoint> getPoints(){
            return points;
        }
    }

}
